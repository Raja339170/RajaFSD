const expect = require('chai').expect;
const calculator = require('../calculator'); //@TODO include your calculator module

// Expecting the signature of the calculator to be like below
/* function calculate(operation, {lhs, rhs}) */

describe('calculator testing', function() {
	describe('Addition functionality testing', function() {
		it('Add two positive numbers, returning get positive sum', function() {
			const lhs = 1;
			const rhs = 2;
			const result = calculator('A', { lhs, rhs });
			expect(result).to.eql(3);
		});

		it('Add two negative numbers, returning get negative sum', function() {
			const lhs = -1;
			const rhs = -2;
			const result = calculator('A', { lhs, rhs });
			expect(result).to.eql(-3);
		});

		it('Add two number, with either of them is negative, producing subtracted output', function() {
			const lhs = 1;
			const rhs = -2;
			const result = calculator('A', { lhs, rhs });
			expect(result).to.eql(-1);
		});

		it('Add zeros, produces zero', function() {
			const lhs = 0;
			const rhs = 0;
			const result = calculator('A', { lhs, rhs });
			expect(result).to.eql(0);
		});
	});

	describe('Subtraction functionality testing', function() {
		it('Subtract two positive numbers, returning get positive subtraction', function() {
			const lhs = 2;
			const rhs = 1;
			const result = calculator('S', { lhs, rhs });
			expect(result).to.eql(1);
		});

		it('Subtract two negative numbers, returning get negative subtraction', function() {
			const lhs = -2;
			const rhs = -1;
			const result = calculator('S', { lhs, rhs });
			expect(result).to.eql(-1);
		});

		it('Subtract two number, with either of them is negative, producing sum output', function() {
			const lhs = -2;
			const rhs = 1;
			const result = calculator('S', { lhs, rhs });
			expect(result).to.eql(-3);
		});

		it('Subtract zeros, produces zero', function() {
			const lhs = 0;
			const rhs = 0;
			const result = calculator('S', { lhs, rhs });
			expect(result).to.eql(0);
		});
	});
	describe('Multiplication functionality testing', function() {

		it('Multiply two positive numbers, returning get positive Multiplication', function() {
			const lhs = 1;
			const rhs = 2;
			const result = calculator('M', { lhs, rhs });
			expect(result).to.eql(2);
		});

		it('Multiply two negative numbers, returning get positive Multiplication', function() {
			const lhs = -1;
			const rhs = -2;
			const result = calculator('M', { lhs, rhs });
			expect(result).to.eql(2);
		});

		it('Multiply two number, with either of them is negative, producing negative multiplication output', function() {
			const lhs = -1;
			const rhs = 2;
			const result = calculator('M', { lhs, rhs });
			expect(result).to.eql(-2);
		});

		it('Multiply zeros, produces zero', function() {
			const lhs = 0;
			const rhs = 0;
			const result = calculator('M', { lhs, rhs });
			expect(result).to.eql(0);
		});
	});

	describe('Division functionality testing', function() {
		it('Divide two positive numbers, returning get positive Multiplication', function() {
			const lhs = 2;
			const rhs = 1;
			const result = calculator('D', { lhs, rhs });
			expect(result).to.eql(2);
		});

		it('Divide two negative numbers, returning get positive Multiplication', function() {
			const lhs = -2;
			const rhs = -1;
			const result = calculator('D', { lhs, rhs });
			expect(result).to.eql(2);
		});

		it('Divide two number, with either of them is negative, producing negative Division output', function() {
			const lhs = -2;
			const rhs = 1;
			const result = calculator('D', { lhs, rhs });
			expect(result).to.eql(-2);
		});

		it(`Should not divide by 0, producing 'Can't divide by zero' message`, function() {
			const lhs = 0;
			const rhs = 0;
			const result = calculator('D', { lhs, rhs });
			expect(result).to.eql('Can not divide by zero');
		});
	});
});

