let notesDAO = require('./notes.dao');
const logger = require('../../../logger');

// handels to insert newly created note into the database
const addNote = (userId, note) => {
  logger.debug('Inside note.service addNote method');
  return notesDAO.addNote(userId, note);
};
// handels to get all notes from database
const getNotes = (userId) => {
  logger.debug('Inside note.service getNotes method');
  return notesDAO.getNotes(userId);
};
// handels to update a note into the database
const updateNote = (noteId, editedNote) => {
  logger.debug('Inside note.service updateNote method');
  return notesDAO.updateNote(noteId, editedNote);
};

module.exports = {
  addNote,
  getNotes,
  updateNote
}