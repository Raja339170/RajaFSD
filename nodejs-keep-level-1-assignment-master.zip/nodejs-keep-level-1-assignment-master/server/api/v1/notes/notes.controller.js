const notesService =  require('./notes.service')
const logger = require('../../../logger');


// Handler to add a note into a database
const addNote = (userId, note) => {
  logger.debug('Inside note.controller addNote method');
  return notesService.addNote(userId, note);
}

// Handler to get notes
const getNotes = (userId) => {
  logger.debug('Inside note.controller getNotes method');
  return notesService.getNotes(userId);
}

// Handler to update note
const updateNote = (noteId, editedNote) => {
  logger.debug('Inside note.controller updateNote method');
  return notesService.updateNote(noteId, editedNote);
}

module.exports = {
  addNote,
  getNotes,
  updateNote
}
