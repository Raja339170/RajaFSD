const router = require('express').Router();
const notesCtrl = require('./notes.controller');
const logger = require('../../../logger');

// api to add a note
router.post('/', (req, res) => {
  logger.debug('Inside note.router addNote');
  let note = req.body;
  let userId = req.query.userId;
  try {
    notesCtrl.addNote(userId, note).then((response) => {
      logger.debug('Inside noteCtrl.addNote success');
      logger.info(response.message);
      res.status(response.status).send(response.note);
    }, 
    (err) => {
      logger.error('Error in noteCtrl.addNote error: ', err.message);
      res.status(err.status).send(err);
    }
    );
  } catch (err) {
    logger.error('Unexpected error in noteCtrl.addNote ', err);
    res.send({message: 'Failed to complete request'})
  }
});
// api to get all notes into database
router.get('/', (req, res) => {
  logger.debug('Inside note.router getNotes');
  let userId = req.query.userId;
  try {
    notesCtrl.getNotes(userId).then((response) => {
      logger.debug('Inside noteCtrl.getNotes success');
      res.status(response.status).send(response.notes);
    }, 
    (err) => {
      logger.error('Error in noteCtrl.getNotes error: ', err.message);
      res.status(err.status).send(err);
    }
    );
  } catch (err) {
    logger.error('Unexpected error in noteCtrl.getNotes ', err);
    res.send({message: 'Failed to complete request'})
  }
});
// api to update a note
router.put('/:noteId', (req, res) => {
  logger.debug('Inside note.router updateNote');
  try {
    let noteId = req.params.noteId;
    let editedNote =  req.body;
    notesCtrl.updateNote(noteId, editedNote).then((response) => {
      logger.debug('Inside noteCtrl.updateNote success');
      logger.info(response.message);
      res.status(response.status).send(response.updatedNote);
    },
    (err) => {
      logger.error('Error in noteCtrl.updateNote error: ', err.message);
      res.status(err.status).send(err);
    }
    );
  } catch (err) {
    logger.error('Unexpected error in noteCtrl.updateNote ', err);
    res.send({message: 'Failed to complete request'})
  }
});

module.exports = router;
