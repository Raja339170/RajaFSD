let noteModel = require('./notes.entity');
const uuidv1 = require('uuid/v1');
const logger = require('../../../logger');

// handels to insert newly created note into the database
const addNote = (userId, note) => {
  logger.debug('Inside note.dao addNote method');
  return new Promise((resolve, reject) => {
    let newNote = new noteModel();
    newNote.id = uuidv1();
    newNote.title = note.title;
    newNote.text = note.text;
    newNote.userId = userId;
    newNote.save((err, note) => {
      if(err) {
        logger.error(err);
        reject({message: 'Internal Server Error', status: 500});
      } else {
        resolve({note: note, message: 'Note is added successfully', status:201});
      }
    });
});
};
// handels to get all notes from database
const getNotes = (userId) => {
  logger.debug('Inside note.dao getNotes method');
  return new Promise((resolve, reject) => {
    noteModel.find({userId: userId}, (err, notes) => {
      if (err) {
        logger.error(err);
        reject({message: 'Internal Server Error', status: 500});
      } else {
        resolve({notes: notes, status:200});
      }
    });
  })
};
// handels to update a note into the database
const updateNote = (noteId, editedNote) => {
  logger.debug('Inside note.dao updateNote method');
  return new Promise((resolve, reject) => {
    delete editedNote['_id'];
    delete editedNote['userId'];
    delete editedNote['createdOn'];
    delete editedNote['id'];
    editedNote['modifiedOn'] = new Date();
    noteModel.findOneAndUpdate({id: noteId}, editedNote, {new: true}, function(err, note) {
      if (err) {
        logger.error(err);
        reject({message: 'Internal Server Error', status: 500});
      } else {
        resolve({updatedNote: note, message: 'Note is updated successfully', status: 200});
      }
    });
  });
};

module.exports = {
  addNote,
  getNotes,
  updateNote
}