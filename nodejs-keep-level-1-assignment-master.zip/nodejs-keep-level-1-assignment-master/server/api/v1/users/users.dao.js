let userModel = require('./users.entity');
let common = require('../../../common');
const uuidv1 = require('uuid/v1');
const logger = require('../../../logger');

const loginUser = (userInfo) => {
  logger.debug('Inside users.dao loginUser method');
  return new Promise((resolve, reject) => {
    userModel.findOne({userName: userInfo.username}, function(err, user) {
      if(err) {
        logger.error(err);
        reject({message: 'Internal Server Error', status: 500});
      } else if(user) {
        // password is correct or not
        common.comparePassword(userInfo.password, user.password, function(error, isMatch) {
          if (isMatch && !error) {
            let userDetail = {userName: user.userName, userId: user.userId};
            resolve({user: userDetail, status: 200});
          } else {
            reject({message: 'Password is incorrect', status: 403});
          }
        });
      } else {
        reject({message: 'You are not registered user', status: 403});
      }
    });
  });
};

const registerUser = (userInfo) => {
  logger.debug('Inside users.dao registerUser method');
  return new Promise((resolve, reject) => {
    userModel.findOne({userName: userInfo.username}, function(err, user) {
      if(err) {
        logger.error(err);
        reject({message: 'Internal Server Error', status: 500});
      } else if(user) {
        reject({message:'username is already exist', status: 403});
      } else {
        let newUser = new userModel();
        newUser.userId = uuidv1();
        newUser.userName = userInfo.username;
        newUser.password = userInfo.password;
        newUser.save(function(error, addedUser) {
          if(error) {
            logger.error(error);
            reject({message: 'Internal Server Error', status: 500});
          } else {
            resolve({message: 'Successfully registered', status: 201, userInfo: addedUser.userName});
          }
        });
      }
    });
  });
 };

 module.exports = {
  loginUser,
  registerUser
 }
