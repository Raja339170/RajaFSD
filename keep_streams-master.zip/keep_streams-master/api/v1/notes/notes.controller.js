const notesService =  require('./notes.services');

// Handler to insert bulk notes
const insertNotesAsStream = () => {
	return notesService.insertNotesAsStream();  
}

// Handler to get bulk notes
const getNotesAsStream = (res) =>{
	return notesService.getNotesAsStream(res);
}

module.exports = {  
  insertNotesAsStream,
  getNotesAsStream
}
