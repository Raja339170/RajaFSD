const router = require('express').Router();
const notesCtrl = require('./notes.controller');

// api to insert bulk notes as stream
router.post('/stream', (req, res) => {
  try {
      notesCtrl.insertNotesAsStream().then((response) => {
        res.status(response.status).send(response.message);
      },
      (err) => {
        res.status(err.status).send(err);
      });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }

});

// api to get all notes from db
router.get('/stream', (req, res) => {
  notesCtrl.getNotesAsStream(res);
});

module.exports = router;
