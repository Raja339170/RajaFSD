const fs = require('fs');
const path = require('path');
/*global require, module,  __dirname */
const matchesFile = path.resolve(__dirname, '../../../mock_notes.json');
const outFile = path.resolve(__dirname, '../../../mock_notes_out.json');
const JSONStream = require('JSONStream');

// Handles to insert bulk data
const insertNotesAsStream = () => {
  return new Promise((resolve) => {
  const writeStream = fs.createWriteStream(outFile);
  const stream = fs.createReadStream(matchesFile);
    stream.pipe(JSONStream.parse('*'))
    .pipe(JSONStream.stringify())
    .pipe(writeStream);
    
    stream.on('end', () => {
      resolve({message: 'Notes updated successfully', status: 200})
    });    
  });
}

// Handles to get bulk data
const getNotesAsStream = (outStream) => {    
  const stream = fs.createReadStream(outFile);

  stream.pipe(JSONStream.stringify())
  .pipe(outStream.type('json'))
}

module.exports = { 
  insertNotesAsStream,
  getNotesAsStream
}
