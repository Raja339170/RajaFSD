let notesDAO = require('./notes.dao');

// handles to insert bulk notes into the database
const insertNotesAsStream = () => {
	return notesDAO.insertNotesAsStream();
}

// handles to get bulk notes from database
const getNotesAsStream = (res) => {
  return notesDAO.getNotesAsStream(res);
}

module.exports = {  
  insertNotesAsStream,
  getNotesAsStream
}
