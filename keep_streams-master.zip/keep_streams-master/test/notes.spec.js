const should = require('chai').should();
const expect = require('chai').expect;
const request = require('supertest');
const app = require('../app');
let mock_notes = require('../mock_notes.json');

describe('Testing notes with bulk data', function()
{
  it('Should handle a request to insert bulk data', function(done) { 
    request(app)
      .post('/api/v1/notes/stream')
      .send(mock_notes)
      .expect(200)
      .end((err, res) => {
        if (err) return done(err);
        (res.text).should.equal('Notes updated successfully');
        done();
      }); 
  });

  it('Should handle a request to get bulk data', function(done) { 
    request(app)
      .get('/api/v1/notes/stream')
      .expect(200)
      .end((err, res) => {
        if (err) return done(err);
        expect(res.body).to.have.lengthOf.above(0);
        done();
      }); 
  });

});
