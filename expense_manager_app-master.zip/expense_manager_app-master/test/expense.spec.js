const assert = require('chai').assert;
const request = require('supertest');
const app = require('../index');
// testsuit starts from here
describe('Expense Manager testing', function () {
  //testsuit for functionality testing
  describe('Functionality testing', function () {
    // testsuit for adding expense
    describe('Adding expense functionality testing', function () {
      // testcase to insert expense record
      it('Should create expense, returning success message', function (done) {
        //write assertion code here and your response should return below given message
        //'Expense record is added successfully'
        request(app)
          .post('/api/expense')
          .set('token', 'express')
          .send({ id: 6, title: 'expense3', category: 'category3', description: 'description3', amount: 30, expenseDate: '16/03/2019' })
          .expect(200)
          .end((err, res) => {
            if (err) return done(err);
            assert.equal(res.text, 'Expense record is added successfully');
            done();
          });

      });
      // testcase to handle, if expense record is already exist with the given id
      it('Should not create expense if expense is already exist with the given id, returning error message', function (done) {
        // write assertion code here and your response should return below given message
        //'Expense record is already exist with the given id'
        request(app)
          .post('/api/expense')
          .set('token', 'express')
          .send({ id: 3, title: 'expense3', category: 'category3', description: 'description3', amount: 30, expenseDate: '16/03/2019' })
          .expect(200)
          .end((err, res) => {
            if (err) return done(err);
            assert.equal(res.text, 'Expense record is already exist with the given id');
            done();
          });
      });
      // testcase to handle, if user is passing empty record.
      it('Should not create expense if passing empty record, returning error message', function (done) {
        // write assertion code here and your response should return below given message
        //'Empty data is not allowed, please provide some valid data to insert record'
        request(app)
          .post('/api/expense')
          .set('token', 'express')
          .expect(200)
          .send({ id: '', title: '', category: '', description: '', amount: '', expenseDate: '' })
          .end((err, res) => {
            if (err) return done(err);
            assert.equal(res.text, 'Empty data is not allowed, please provide some valid data to insert record');
            done();
          });
      });
      // testcase to handle, if user is not passing any record in post body.
      it('Should not create expense if user is not passing any record in post request, returning error message', function (done) {
        // write assertion code here and your response should return below given message
        // 'Please provide some data to add new expense'
        request(app)
          .post('/api/expense')
          .set('token', 'express')
          .expect(200)
          .send({})
          .end((err, res) => {
            if (err) return done(err);
            assert.equal(res.text, 'Please provide some data to add new expense');
            done();
          });
      });
      // testcase to handle, if user is passing wrong key as a record.
      it('Should not create expense if user is passing wrong data, returning error message', function (done) {
        // write assertion code here and your response should return below given message
        // 'Please provide values for id ,title, category, description, amount and expenseDate. All are mandatory data elements'
        request(app)
          .post('/api/expense')
          .set('token', 'express')
          .expect(200)
          .send({ id: 'Aid', title: 'title5', category: 'category5', description: 'description6', amount: 'Aamount', expenseDate: 'Adate' })
          .end((err, res) => {
            if (err) return done(err);
            assert.equal(res.text, 'Please provide values for id ,title, category, description, amount and expenseDate. All are mandatory data elements');
            done();
          });
      });
    });

    // testsuit to get all expense record
    describe('Getting all expense functionality testing', function () {
      it('Should get all expense, returning array of expense ', function (done) {
        // write assertion code here and check response array length, it should be greater than zero
        request(app)
          .get('/api/expense')
          .set('token', 'express')
          .expect(200)
          .end((err, res) => {
            if (err) return done(err);
            assert.isArray(res.body);
            assert.isNotEmpty(res.body);
            done();
          });
      });
    });
    // testsuit to update expense record
    describe('Updating expense functionality testing', function () {
      // testcase to update particular expense category
      it('Should search expense by id and update expense category, returning success message', function (done) {
        // write assertion code here and your response should return below given message
        // 'Expense record is updated successfully'
        request(app)
          .put('/api/expense')
          .set('token', 'express')
          .expect(200)
          .send({ id: 5, title: 'electricity bill', category: 'bill', description: 'jan bill', amount: '80000', expenseDate: '01/01/2018' })
          .end((err, res) => {
            if (err) return done(err);
            assert.equal(res.text, 'Expense record is updated successfully');
            done();
          });
      });
      // testcase to handle, if no expense record will be found by given category
      it('Should search expense by category if expense is not found with the given category, returning error message', function (done) {
        // write assertion code here and your response should return below given message
        // 'Expense record is not found with the given category'
        request(app)
          .get('/api/expense/category/testing')
          .set('token', 'express')
          .expect(200)
          .end((err, res) => {
            if (err) return done(err);
            assert.equal(res.text, 'Expense record is not found with the given category');
            done();
          });
      });
      // testcase to handle, if user is passing empty record.
      it('Should not update expense if passing empty record, returning error message', function (done) {
        // write assertion code here and your response should return below given message
        // 'Empty data is not allowed, please provide some valid data to update record'
        request(app)
          .put('/api/expense')
          .set('token', 'express')
          .expect(200)
          .send({ id: '', title: '', category: '', description: '', amount: '', expenseDate: '' })
          .end((err, res) => {
            if (err) return done(err);
            assert.equal(res.text, 'Empty data is not allowed, please provide some valid data to update record');
            done();
          });
      });
      it('Should not update expense if user is not passing any record in update request, returning error message', function (done) {
        // write assertion code here and your response should return below given message
        // 'Please provide id and some data to update expense record'
        request(app)
          .put('/api/expense')
          .set('token', 'express')
          .expect(200)
          .send({})
          .end((err, res) => {
            if (err) return done(err);
            assert.equal(res.text, 'Please provide id and some data to update expense record');
            done();
          });
      });
      // testcase to handle, if user is not passing id in update request.
      // testcase to handle, if user is not passing any record in put body.
      it('Should not update expense if passing without any id, returning error message', function (done) {
        // write assertion code here and your response should return below given message
        // 'Please provide expense id to update record'
        request(app)
          .put('/api/expense')
          .set('token', 'express')
          .expect(200)
          .send({ title: 'electricity bill', category: 'bill', description: 'jan bill', amount: '80000', expenseDate: '01/01/2018' })
          .end((err, res) => {
            if (err) return done(err);
            assert.equal(res.text, 'Please provide expense id to update record');
            done();
          });
      });
      // testcase to handle, if user is passing id only id not other field values.
      it('Should not update expense if passing only id not other fields, returning error message', function (done) {
        // write assertion code here and your response should return below given message
        // 'Please provide values those needs to update'
        request(app)
          .put('/api/expense')
          .set('token', 'express')
          .expect(200)
          .send({ id: 15, title: '', category: '', description: '', amount: '', expenseDate: '' })
          .end((err, res) => {
            if (err) return done(err);
            assert.equal(res.text, 'Please provide values those needs to update');
            done();
          });
      });
    });
    // testsuit to search and get expense record according to given condition
    describe('Searching expense functionality testing', function () {
      // testcase to get all expense those are matching with given start and end date
      it('Should search expense by start and end date, returning matching expense data as an array', function (done) {
        // write assertion code here and check response array length, it should be greater than zero
        request(app)
          .get('/api/expense')
          .set('token', 'express')
          .send({ start: '26/05/2017', end: '26/12/2017' })
          .expect(200)
          .end((err, res) => {
            if (err) return done(err);
            assert.isArray(res.body);
            assert.isNotEmpty(res.body);
            done();
          });
      });
      // testcase to get all expense, those are equal to given start date and greater than given start date
      it('Should search expense by start date only, returning expense data where date is greater than and equal to the given start date', function (done) {
        // write assertion code here and check response array length, it should be greater than zero
        request(app)
          .get('/api/expense')
          .set('token', 'express')
          .send({ start: '26/12/2017' })
          .expect(200)
          .end((err, res) => {
            if (err) return done(err);
            assert.isArray(res.body);
            assert.isNotEmpty(res.body);
            done();
          });
      });
      // testcase to get all expense those are matching with given category, start and end date.
      it('Should search expense by category, start and end date, returning matching expense data as an array', function (done) {
        // write assertion code here and check response array length, it should be greater than zero
        request(app)
          .get('/api/expense')
          .set('token', 'express')
          .send({ category: 'fair', start: '26/05/2017', end: '26/12/2018' })
          .expect(200)
          .end((err, res) => {
            if (err) return done(err);
            assert.isArray(res.body);
            assert.isNotEmpty(res.body);
            done();
          });
      });
      // // testcase to get all expense, those are equal to given category, start date and greater than given start date
      it('Should search expense by category and start date only, returning expense data matching with given category and date should be greater than and equal to start date', function (done) {
        // write assertion code here and check response array length, it should be greater than zero
        request(app)
          .get('/api/expense')
          .set('token', 'express')
          .send({ category: 'fair', start: '26/05/2017' })
          .expect(200)
          .end((err, res) => {
            if (err) return done(err);
            assert.isArray(res.body);
            assert.isNotEmpty(res.body);
            done();
          });
      });
      // // testcase to get all expense, those are equal to given category, start date and greater than given start date
      it('Should handle 404 error if route not matched, returning Not Found message', function (done) {
        // write assertion code here and your response should return below given message
        // 'Not Found'
        request(app)
          .get('/api/expens/novalue')
          .set('token', 'express')
          .send({ category: 'fair', start: '26/05/2017' })
          .expect(404)
          .end((err, res) => {
            if (err) return done(err);
            assert.equal(res.text, 'Not Found');
            done();
          });
      });
    });
    // testsuit to delete a expense record
    describe('Deleting expense functionality testing', function () {
      // testcase to delete expense record by given id
      it('Should search expense by id and delete particular expense record, returning success message', function (done) {
        // write assertion code here and your response should return below given message
        // 'Expense record is deleted successfully'
        request(app)
          .delete('/api/expense/5')
          .set('token', 'express')
          .expect(200)
          .end((err, res) => {
            if (err) return done(err);
            assert.equal(res.text, 'Expense record is deleted successfully');
            done();
          });
      });
       // testcase to handle, if no expense record will be found by given id
        it('Should search expense by id if expense is not found with the given id, returning error message', function (done) {
          // write assertion code here and your response should return below given message
          // 'Expense record is not found with the given id'
          request(app)
            .get('/api/expense/id/10')
            .set('token', 'express')
            .expect(200)
            .end((err, res) => {
              if (err) return done(err);
              assert.equal(res.text, 'Expense record is not found with the given id');
              done();
            });
        });

        it('should send us 404 for Route not found', function(done) {
          request(app)
              .get('/api')
              .set('token', 'express')
              .expect(404)
              .end((err, res) => {
                  if(err) return done(err);
                  assert.equal(res.text, 'Not Found')
                  done();
              });
        });
      // testcase to handle, if user is not passing any record in delete body.
      it('Should not delete expense if user is not passing any record in delete request, returning error message', function (done) {
        // write assertion code here and your response should return below given message
        // 'Please provide expense id to delete expense record'
        request(app)
          .delete('/api/expense')
          .set('token', 'express')
          .expect(200)
          .send({})
          .end((err, res) => {
            if (err) return done(err);
            assert.equal(res.text, 'Please provide expense id to delete expense record');
            done();
          });
      });
      // testcase to handle, if user is not passing id in delete request body.
      it('Should not delete expense if not passing id, returning error message', function (done) {
        // write assertion code here and your response should return below given message
        // 'Please provide expense id to delete expense record'
        request(app)
          .delete('/api/expense')
          .set('token', 'express')
          .expect(200)
          .send({ id: '' })
          .end((err, res) => {
            if (err) return done(err);
            assert.equal(res.text, 'Please provide expense id to delete expense record');
            done();
          });
      });
    });
  });
});
