const router = require('express').Router();
const expenses = require('../../../db.json');

// write all routing code and logic here

router.get('/', (req, res) => {
    if (!(JSON.stringify(req.body) === JSON.stringify({})) && !isEmpty(req.body)) {

        if (hasProp(req.body, 'category') && hasProp(req.body, 'start') && hasProp(req.body, 'end')) {
            const startDate = stringToDate(req.body.start.toString());
            const endDate = stringToDate(req.body.end.toString());
            const category = req.body.category;

            if (startDate && endDate && category) {
                const expense = expenses.filter((expense) => {
                    const expenseDate = stringToDate(expense.expenseDate.toString());
                    return (expense.category == category && expenseDate >= startDate && expenseDate <= endDate);
                });

                if (expense) {
                    res.status(200).send(expense);
                }
            }
        }
        else if (hasProp(req.body, 'category') && hasProp(req.body, 'start')) {
            const startDate = stringToDate(req.body.start.toString());
            const category = req.body.category;

            if (startDate && category) {
                const expense = expenses.filter((expense) => {
                    const expenseDate = stringToDate(expense.expenseDate.toString());
                    return (expense.category == category && expenseDate >= startDate);
                });

                if (expense) {
                    res.status(200).send(expense);
                }
            }
        }
        else if (hasProp(req.body, 'start') && hasProp(req.body, 'end')) {
            const startDate = stringToDate(req.body.start.toString());
            const endDate = stringToDate(req.body.end.toString());

            if (startDate && endDate) {
                const expense = expenses.filter((expense) => {
                    const expenseDate = stringToDate(expense.expenseDate.toString());
                    return (expenseDate >= startDate && expenseDate <= endDate);
                });

                if (expense) {
                    res.status(200).send(expense);
                }
            }
        }
        else if (hasProp(req.body, 'start')) {
            const startDate = stringToDate(req.body.start.toString());

            if (startDate) {
                const expense = expenses.filter((expense) => {
                    const expenseDate = stringToDate(expense.expenseDate.toString());
                    return (expenseDate >= startDate);
                });

                if (expense) {
                    res.status(200).send(expense);
                }
            }
        }
    }
    else {
        res.status(200).send(expenses);
    }
    res.status(200).send();
});

router.get('/id/:id', (req, res) => {
    const expense = expenses.find((expense) => {
        return expense.id == req.params.id;
    });
    if (!expense) {
        res.status(200).send('Expense record is not found with the given id');
    } else {
        res.status(404).send('Not Found');
    }
    res.status(200).send();
});

router.get('/category/:category', (req, res) => {
    const expense = expenses.find((expense) => {
        return expense.category == req.params.category;
    });
    if (!expense) {
        res.status(200).send('Expense record is not found with the given category');
    } else {
        res.status(404).send('Not found');
    }
    res.status(200).send();
});

router.post('/', (req, res) => {
    // console.log('Data: ' + JSON.stringify(req.body));

    if (JSON.stringify(req.body) === JSON.stringify({})) {
        res.status(200).send('Please provide some data to add new expense');
    }
    else if (!(JSON.stringify(req.body) === JSON.stringify({})) && isEmpty(req.body)) {
        res.status(200).send('Empty data is not allowed, please provide some valid data to insert record');
    }
    else if (!(JSON.stringify(req.body) === JSON.stringify({})) && isInValid(req.body)) {
        res.status(200).send('Please provide values for id ,title, category, description, amount and expenseDate. All are mandatory data elements');
    }
    else {
        const expense = expenses.find((expense) => {

            return expense.id == req.body.id;
        });
        if (expense) {
            res.status(200).send('Expense record is already exist with the given id');
        } else {
            expenses.push(req.body);
            res.status(200).send('Expense record is added successfully');
        }
    }
});

router.put('/', (req, res) => {
    let expenseIndex = undefined;

    if (JSON.stringify(req.body) === JSON.stringify({})) {
        res.status(200).send('Please provide id and some data to update expense record');
    }

    if (!(JSON.stringify(req.body) === JSON.stringify({})) && isEmptyExceptId(req.body, 'id')) {
        res.status(200).send('Please provide values those needs to update');
    }
    else if (!(JSON.stringify(req.body) === JSON.stringify({})) && isEmpty(req.body)) {
        res.status(200).send('Empty data is not allowed, please provide some valid data to update record');
    }

    if (!(JSON.stringify(req.body) === JSON.stringify({})) && !isEmpty(req.body) && !hasProp(req.body, 'id')) {
        res.status(200).send('Please provide expense id to update record');
    }

    const expense = expenses.find((expense, index) => {
        expenseIndex = index;
        return expense.id == req.body.id;
    });

    if (expense) {
        expenses[expenseIndex] = req.body;
        res.status(200).send('Expense record is updated successfully');
    }
    res.status(200).send();
});

router.delete('/:id', (req, res) => {
    let expenseIndex = undefined;

    const expense = expenses.find((expense, index) => {
        expenseIndex = index;
        return expense.id == req.params.id;
    });

    if (expense) {
        expenses.splice(expenseIndex, 1);
        res.status(200).send('Expense record is deleted successfully');
    }
    res.status(200).send();
});

router.delete('/', (req, res) => {
    if (JSON.stringify(req.body) === JSON.stringify({})) {
        res.status(200).send('Please provide expense id to delete expense record');
    }
    else if (!(JSON.stringify(req.body) === JSON.stringify({})) && isEmpty(req.body)) {
        res.status(200).send('Please provide expense id to delete expense record');
    }

    let expenseIndex = undefined;

    const expense = expenses.find((expense, index) => {
        expenseIndex = index;
        return expense.id == req.body.id;
    });

    if (expense) {
        expenses.splice(expenseIndex, 1);
        res.status(200).send('Expense record is deleted successfully');
    }
  //  res.status(200).send();
});

function hasProp(obj, propName) {
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop) && prop == propName)
            return true;
    }
    return false;
}

function isEmptyExceptId(obj, propName) {

    for (var prop in obj) {
        if (obj.hasOwnProperty(prop) && obj.hasOwnProperty(propName)) {
            if (obj[propName].toString().length > 0 && obj[prop].toString().length == 0)
                return true;
        }
    }
    return false;
}

function isEmpty(obj) {
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop) && obj[prop].toString().length == 0)
            return true;
    }
    return false;
}

function isInValid(obj) {
    if (isEmpty(obj)) return true;

    for (var prop in obj) {
        if (obj.hasOwnProperty(prop)) {
            if ((prop == 'id' && isNaN(obj[prop])) ||
                (prop == 'amount' && isNaN(obj[prop]))
            ) return true;

            if (prop == 'expenseDate' && !isDate(obj[prop])) return true;
        }
    }
    return false;
}

function isDate(expenseDate) {
    var objDate,  // date object initialized from the expenseDate string 
        mSeconds, // expenseDate in milliseconds 
        day,      // day 
        month,    // month 
        year;     // year 
    // date length should be 10 characters (no more no less) 
    if (expenseDate.length !== 10) {
        return false;
    }
    // third and sixth character should be '/' 
    if (expenseDate.substring(2, 3) !== '/' || expenseDate.substring(5, 6) !== '/') {
        return false;
    }
    // extract month, day and year from the expenseDate (expected format is mm/dd/yyyy) 
    // subtraction will cast variables to integer implicitly (needed 
    // for !== comparing) 
    day = parseInt(expenseDate.substring(0, 2)) + 1;
    month = expenseDate.substring(3, 5) - 1;
    year = expenseDate.substring(6, 10);

    mSeconds = (new Date(year, month, day)).getTime();
    // initialize Date() object from calculated milliseconds 
    objDate = new Date();
    objDate.setTime(mSeconds);

    // compare input date and parts from Date() object 
    // if difference exists then date isn't valid 
    if (objDate.getFullYear() !== parseInt(year) ||
        objDate.getMonth() !== parseInt(month) ||
        objDate.getDate() !== parseInt(day)) {
        return false;
    }
    // otherwise return true 
    return true;
}

function stringToDate(expenseDate) {
    let objDate,  // date object initialized from the expenseDate string 
        mSeconds, // expenseDate in milliseconds 
        day,      // day 
        month,    // month 
        year;     // year 

    if (isDate(expenseDate)) {
        day = parseInt(expenseDate.substring(0, 2)) + 1;
        month = expenseDate.substring(3, 5) - 1;
        year = expenseDate.substring(6, 10);
        mSeconds = (new Date(year, month, day)).getTime();
        // initialize Date() object from calculated milliseconds 
        objDate = new Date();
        objDate.setTime(mSeconds);
        return objDate;
    }
    return false;
}

module.exports = router;
