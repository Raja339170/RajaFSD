const express = require('express');
const api = require('./server/api');
const app = express();
// import modules which you required

// write middlewares here those will be executed before processing any request
app.use(express.urlencoded({extended: false}));
app.use(express.json());
// bootpoint from where routing starts
app.use((req, res, next) => {
    next();
},(req, res, next) => {
    if(req.get('token') === 'express') {
        next();
    } else {
        next(401);
    }
});

app.use('/api', api);

app.use((req, res) => {
    res.sendStatus(404);
});

app.use((err, req, res) => {
    res.sendStatus(err);
});

module.exports = app;
