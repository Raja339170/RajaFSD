const db = require('./db');
const { generateToken, verifyToken } = require('./api/v1/auth');

/* Replace undefined with Require of your Mongoose connection initialization method */
const initializeMongooseConnection = db.createMongoConnection();
/* Replace undefined with Require of your note entity*/
const noteModel = require('./api/v1/notes/notes.entity.js');
/* Replace undefined with Require of your user entity*/
const userModel = require('./api/v1/users/users.entity.js');
const signJWTToken=generateToken ;
const verifyJWTToken=verifyToken;


module.exports = {
	initializeMongooseConnection,
	noteModel,
	userModel,
	signJWTToken,
	verifyJWTToken
}