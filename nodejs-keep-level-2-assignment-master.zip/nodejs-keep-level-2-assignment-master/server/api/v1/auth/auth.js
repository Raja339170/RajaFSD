let bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { authConfig } = require('../../../config').appConfig;

// handler to compare password
const comparePassword = (givenPW, savedPW, cb) => {
  bcrypt.compare(givenPW, savedPW, function (err, isMatch) {
    if (err) {
      cb(err);
    }
    cb(null, isMatch);
  });
};

// handler to generate token
/*const generateToken = (payload, done) => {
  jwt.sign(payload, authConfig.jwtSecret, {expiresIn: '10h'}, done);
}*/

const generateToken = (payload, secret, expireIn, done) => {
  jwt.sign(payload, secret, {expiresIn: expireIn}, done);
}

// handler to verify token
/*const verifyToken = (token, done) => {
  jwt.verify(token, authConfig.jwtSecret, done);
}*/
const verifyToken = (token,secret, done) => {
  jwt.verify(token, secret, (err, decoded) => {
    if (err) {
     done(err.message);
    } else done(err, decoded);
  });
}

// handler to protect all api
const isAuthenticatedUser = (req, res, next) => {
  const authorizationHeader = req.get('Authorization');
  if (!authorizationHeader) {
    //res.status(403).json({ isAuthenticated: false, message:'Not authenticated' });
    res.status(403).send('Not authenticated');
  }
  const token = authorizationHeader.replace('Bearer ', '');
  verifyToken(token, authConfig.jwtSecret, (err, decoded) => {
    if (err) {
      //res.status(403).json({ isAuthenticated: false, message:'invalid token' });
      res.status(403).send('invalid token');
    } else {
      req.userId = decoded.userId;
      next();
    }
  })
}

module.exports = {
  comparePassword,
  generateToken,
  verifyToken,
  isAuthenticatedUser
}
