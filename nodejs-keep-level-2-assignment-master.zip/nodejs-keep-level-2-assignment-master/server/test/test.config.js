//  Test Configuration Object
//  Test Configuration Object
module.exports = {
    note_user1: {
      title: 'Angular needs to learn',
      text: 'This is angular note',
      status: 'not-started'
    },
    note_user2: {
      title: 'React needs to learn',
      text: 'This is react note',
      status: 'not-started'
    },
    updateNote: {
      title: 'Angular needs to learn',
      text: 'This is angular 6 note',
      status: 'not-started'
    },
    user1: {
      username: 'admin4@gmail.com',
      password: 'admin'
    },
    user2: {
      username: 'admin5@gmail.com',
      password: 'admin'
    },
    user3: {
      username: 'admin6@gmail.com',
      password: 'admin'
    },
    user: {
      username: 'admin@gmail.com',
      password: 'admin'
    },
    wrongPassword: {
      username: 'admin@gmail.com',
      password: 'admin1'
    },
    wrongUserName: {
        username: 'admin1@gmail.com',
        password: 'admin1'
    },
    secret: 'abjwtokenxyz',
    payload: { 
      username: 'abc',
      password: 'xyz'
    },
    expireIn: '10m',
    expireInSecond: '1ms'
  };
  