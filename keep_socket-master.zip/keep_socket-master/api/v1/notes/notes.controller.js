const notesService =  require('./notes.services');

const getSharedNotes = () =>{
	return notesService.getSharedNotes();
}

const shareNotes = (emailId, notes) => {
  return notesService.shareNotes(emailId, notes);
}

module.exports = {
  shareNotes,
  getSharedNotes
}
