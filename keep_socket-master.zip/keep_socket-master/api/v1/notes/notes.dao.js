const fs = require('fs');
const path = require('path');
/*global require, module,  __dirname */
const outFile = path.resolve(__dirname, '../../../mock_notes_out.json');

// Handles to insert bulk data
const saveNotes = (emailId, notes) => {
  return new Promise((resolve) => {
    fs.writeFileSync(outFile, JSON.stringify(notes));
    resolve({message: 'Shared Successfully', status: 201});  
  });
}

// Handles to get bulk data
const getSharedNotes = () => { 
  return new Promise((resolve) => { 
    let resNotes = {};   
    fs.readFileSync(outFile, function(err, data) { 
      if (err) throw err;
      resNotes = data;    
    }); 
    resolve({message: 'Get all the nodes', status: 200, notes: resNotes});
  });
}

module.exports = {
  saveNotes,
  getSharedNotes
}
