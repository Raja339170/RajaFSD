const router = require('express').Router();
const notesCtrl = require('./notes.controller');
const socketObj = require('../../../socket/socketServer');

// api to share selected notes
router.post('/share', (req, res) => {
  let notes = req.body;
  let emailId = req.query.userName;
  let socket = socketObj.getSocket();
  
  try {
    notesCtrl.shareNotes(emailId, notes).then((response) => {
      socket.emit(emailId, 'notesShared');
      res.status(response.status).send(response);
    },
    (err) => {
      res.status(err.status).send(err);
    });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});

// api to get shared notes
router.get('/share', (req, res) => {
  try {
    notesCtrl.getSharedNotes().then((response) => {      
      res.status(response.status).send(response);
    },
    (err) => {
      res.status(err.status).send(err);
    });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }  
});


module.exports = router;
