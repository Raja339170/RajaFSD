let mongoose = require('mongoose');

let Schema = mongoose.Schema;

// define the noteSchema model
const NoteSchema = new Schema({
  id: {
    type: String,
    required: true
  },
  title: {
    type: String,
    required: true
  },
  text: {
    type: String,
    required: true
  },
  state: {
    type: String,
    default: 'not-started'
  },
  userId: {
    type: String,
    required: true
  },
  accessType: {
    type: String,
    default: 'read-write'
  },
  createdOn: {
    type: Date,
    default: Date.now()
  },
  modifiedOn: {
    type: Date,
    default: Date.now()
  }
});

module.exports = mongoose.model('notes', NoteSchema);
