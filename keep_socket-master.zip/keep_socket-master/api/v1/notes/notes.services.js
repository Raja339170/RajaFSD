let notesDAO = require('./notes.dao');

const getSharedNotes = () => {
  return new Promise((resolve, reject) => {
    notesDAO.getSharedNotes().then(
      res => {
        resolve(res);          
      },
      err => {
        reject(err);
      }
    )
  });
}

// handles to share notes to another user
const shareNotes = (emailId, notes) => {  
  return new Promise((resolve, reject) => {
    if(!emailId) {
      reject({message: 'Please enter valid email ID to share', status:403});
    }
    else {
      notesDAO.saveNotes(notes).then(
        res => {
          resolve(res);          
        },
        err => {
          reject(err);
        }
      )    
    }
  });
}

module.exports = {
  shareNotes,
  getSharedNotes
}
