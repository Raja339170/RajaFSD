const should = require('chai').should();
const expect = require('chai').expect;
const request = require('supertest');
const app = require('../app');
let mock_notes = require('../mock_notes.json');
const { socketConfig } = require('../config').appConfig;

let shareToEmail = 'admin@gmail.com';

describe('Testing notes by sharing using socket', function()
{
  let socket;
  before((done) => {
    let url = 'http://'+socketConfig.hostname+':'+socketConfig.port;
    socket = require('socket.io-client')(url);
    socket.on('connected', (data) => {
        console.log("connected :: ", data);
        done();
    }); 
  });

  it('Should handle a request to share notes with emailId', function(done) { 
   
    request(app)
      .post('/api/v1/notes/share?userName='+shareToEmail)
      .send(mock_notes)
      .expect(201)
      .end((err, res) => {
        if (err) return done(err); 
        (res.body.message).should.equal('Shared Successfully'); 
        done();
      }); 
  });

  it('Should handle a request to share notes with emailId that should send data through socket', function(done) { 
    request(app)
      .post('/api/v1/notes/share?userName='+shareToEmail)
      .send(mock_notes)
      .expect(201)
      .end((err, res) => {
        if (err) return done(err); 
        (res.body.message).should.equal('Shared Successfully'); 
      });

      socket.on(shareToEmail, data => {
        expect(data).to.have.lengthOf.above(0);
        done();
      });
  });
});

describe('Testing notes by get all notes', function()
{
  it('Should handle a request to get shared notes', function(done) { 
    request(app)
      .get('/api/v1/notes/share')
      .expect(200)
      .end((err, res) => {
        if (err) return done(err);
        (res.body.message).should.equal('Get all the nodes');
        done();
      }); 
  });

});
