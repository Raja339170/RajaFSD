
const { socketConfig } = require('../config').appConfig;
const http = require('http');
const socketServer = http.createServer();
const io = require('socket.io')(socketServer);

let localSocket;

io.on('connection', (socket) => {
    localSocket = socket;
    socket.emit('connected', 'success');
});

// Getter method to return the created socket
getSocket = () => {
  return io;
}

socketServer.listen(socketConfig.port, () => {
  console.log(`Server listening on port : ${socketConfig.port}`);
});

module.exports = {
  socketServer,
  getSocket
};