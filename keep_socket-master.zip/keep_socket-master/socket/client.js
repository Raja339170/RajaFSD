const { socketConfig } = require('../config').appConfig;
const socket = require('socket.io-client')('http://'+socketConfig.hostname+':'+socketConfig.port);

socket.on('connected', (data) => {
    console.log("connected :: ", data);
});

socket.on('admin@gmail.com', (data) => {
    console.log(data);
});
