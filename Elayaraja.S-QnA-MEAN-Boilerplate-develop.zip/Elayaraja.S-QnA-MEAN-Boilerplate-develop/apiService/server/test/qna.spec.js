const should = require('chai').should(); // eslint-disable-line no-unused-vars
const request = require('supertest');
const app = require('../app');
const config = require('./test.config');
const modules = require('../modules');
const uuidv4 = require('uuid/v4');

let userToken;
let questionID;

// Initialize db connection before all tests
before((done) => {
  modules.initializeMongooseConnection()
    .then(() => {
      done();
    });
});

// register user
before((done) => {
  done();
});

// Get JWT token for user 1
before((done) => {
  const user1 = config.userInfo.user1;
  const auth = config.auth;
  modules.signJWTToken(user1, auth.secret, auth.expiresInOneHour, (err, token) => {
      if(err) return done(err);
      userToken = token;
      done();
  });
});

//  testsuite
describe('Testing to get all topics', function()
{
  //  testcase
  it('Should handle a request to get all topics', function(done)
  {
    request(app)
      .get('/api/v1/question/topic')
      .set('Authorization', 'Bearer ' + userToken)
      .expect(200)
      .end((error, response) => {
        if(error) return done(error);
        const questions = response.body;
        questions.should.be.an('array');
        questions.length.should.be.above(0);
        done();
      });   
  });
});

//  testsuite
describe('Testing to add a question', function()
{
  //  testcase
  it('Should handle a request to add a question for Topic1', function(done)
  {   
    const question = config.question;
    request(app)
      .post('/api/v1/question')
      .set('Authorization', 'Bearer ' + userToken)
      .send(question)
      .expect(201)
      .end((error, response) => {
        if(error) return done(error);
        const questionTitle = response.body.title;
        questionID = response.body.id;
        questionTitle.should.equal(question.title, 'response should have matching question title');
        done();
      });
  });
});

//  testsuite
describe('Testing to get all questions', function()
{
  //  testcase
  it('Should handle a request to get all question of Topic1', function(done)
  {
    request(app)
      .get('/api/v1/question?topicId=1')
      .set('Authorization', 'Bearer ' + userToken)
      .expect(200)
      .end((error, response) => {
        if(error) return done(error);
        const questions = response.body;
        questions.should.be.an('array');
        questions.length.should.be.above(0);
        done();
      });   
  });
});

//  testsuite
describe('Testing to add a comment', function()
{
  //  testcase
  it('Should handle a request to add a comment for Question1', function(done)
  {   
    const answer = config.answer;
    answer.questionId = questionID;
    request(app)
      .post('/api/v1/question/answer')
      .set('Authorization', 'Bearer ' + userToken)
      .send(answer)
      .expect(201)
      .end((error, response) => {
        if(error) return done(error);
        const answerText = response.body.text;
        answerText.should.equal(answer.text, 'response should have matching answer text');
        done();
      });
  });
});

//  testsuite
describe('Testing to get all answers', function()
{
  //  testcase
  it('Should handle a request to get all answers of Question1', function(done)
  {
    request(app)
      .get(`/api/v1/question/detail?questionId=${questionID}`)
      .set('Authorization', 'Bearer ' + userToken)
      .expect(200)
      .end((error, response) => {
        if(error) return done(error);
        const answers = response.body.answers;
        answers.should.be.an('array');
        answers.length.should.be.above(0);
        done();
      });   
  });
});
