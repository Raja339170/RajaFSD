const answerDao = require('./answer.dao');
const log = require('../../../logging');

const getAnswersByQuestionId = (questionId) => {
  return answerDao.getAnswersByQuestionId(questionId)
}

const createAnswer = (userId, fullName, answer) => {
  return answerDao.createAnswer(userId, fullName, answer);
}

module.exports = {
  getAnswersByQuestionId,
  createAnswer
}