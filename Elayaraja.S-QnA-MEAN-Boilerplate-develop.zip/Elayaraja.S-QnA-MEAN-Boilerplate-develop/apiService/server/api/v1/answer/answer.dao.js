let answerModel = require('./answer.entity');
const uuidv4 = require('uuid/v4');

const log = require('../../../logging');

const createAnswer = (userId, fullName, answer) =>{
  return new Promise((resolve, reject) => {
    try {
      let newAnswer = new answerModel({
        id: uuidv4(),        
        text: answer.text,
        userId: userId,
        fullName: fullName,
        questionId: answer.questionId
      });

      log.info('saving answer in database');
      newAnswer.save(function(error, addedAnswer) {
        if(error) {
          log.error(error);
          reject({ message: 'Failed to create answer due to unexpected error', status: 500 });
        } else {
          resolve({ message: 'Successfully created', status: 201, answer: addedAnswer });
        }
      });
    } catch (err) {
      log.error(err);
      reject({ message: 'Failed to create answer due to unexpected error', status: 500 });
    }
  });
}

module.exports = {
  createAnswer
}
