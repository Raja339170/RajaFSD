const router = require('express').Router();
const answerController = require('./answer.controller');

router.post('/', answerController.createAnswer);

module.exports = router;
