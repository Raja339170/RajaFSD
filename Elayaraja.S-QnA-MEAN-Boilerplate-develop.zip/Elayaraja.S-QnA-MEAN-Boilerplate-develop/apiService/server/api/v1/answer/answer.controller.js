const answerService = require('./answer.service');

const createAnswer = (req, res) => {
  const answer = req.body;
  const userId = req.query.userId || req.userData.userId;
  const fullName = req.query.fullName || req.userData.fullName;
  answerService.createAnswer(userId, fullName, answer)
    .then((result) => {
      res.status(result.status).json(result.answer);
    })
    .catch((error) => {
      res.status(error.status).json(error);
    });
};

module.exports = { 
  createAnswer  
}
