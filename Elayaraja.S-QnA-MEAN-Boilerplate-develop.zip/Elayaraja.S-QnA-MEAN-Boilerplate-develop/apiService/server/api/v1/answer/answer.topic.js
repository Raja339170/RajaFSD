module.exports = [ 
    {'questionId' : '1', 'questionName': 'Node'},
    {'questionId' : '2', 'questionName': 'Angular'}
];
