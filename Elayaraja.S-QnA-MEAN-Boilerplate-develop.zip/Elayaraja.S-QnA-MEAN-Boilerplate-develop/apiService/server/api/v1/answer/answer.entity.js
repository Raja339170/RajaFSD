const mongoose = require('mongoose');

let answerSchema = new mongoose.Schema({
  id: {
    type: String,
    lowercase: true,
    unique: true,
    required: true,
  },
  text: {
    type: String,
    required: true
  },  
  userId: {
    type: String,
    required: true
  },
  fullName: {
    type: String,
    required: true
  },
  questionId: {
    type: String,
    required: true
  },
  createdOn: {
    type: String,
    default: Date.now(),
    required: true
  },
  modifiedOn: {
    type: String,
    default: Date.now(),
    required: true
  }
});

module.exports = mongoose.model('answer', answerSchema);
