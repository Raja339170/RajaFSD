module.exports = [ 
    {'topicId' : '1', 'topicName': 'Node'},
    {'topicId' : '2', 'topicName': 'Angular'},
    {'topicId' : '3', 'topicName': 'Javascript'},
    {'topicId' : '4', 'topicName': 'HTML'},
    {'topicId' : '5', 'topicName': 'React'}
];
