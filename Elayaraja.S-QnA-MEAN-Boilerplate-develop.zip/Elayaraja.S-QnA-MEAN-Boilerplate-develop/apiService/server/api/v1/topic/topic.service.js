const topicDao = require('./topic.dao');
const log = require('../../../logging');

const getTopics = () => {
  return topicDao.getTopics();
}

const createTopic = (userId, topic) => {
  return topicDao.createTopic(userId, topic);
}


module.exports = {
  getTopics,
  createTopic
}