module.exports = require('./topic.router');
