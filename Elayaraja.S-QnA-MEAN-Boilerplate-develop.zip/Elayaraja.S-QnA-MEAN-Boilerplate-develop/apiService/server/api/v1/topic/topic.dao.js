let topicModel = require('./topic.entity');
const uuidv4 = require('uuid/v4');

const log = require('../../../logging');

const createTopic = (userId, topic) =>{
  return new Promise((resolve, reject) => {
    try {
      let newTopic = new topicModel({
        id: uuidv4(),
        title: topic.title,
        userId: userId
      });

      log.info('saving topic in database');
      newTopic.save(function(error, addedTopic) {
        if(error) {
          log.error(error);
          reject({ message: 'Failed to create topic due to unexpected error', status: 500 });
        } else {
          resolve({ message: 'Successfully created', status: 201, topic: addedTopic });
        }
      });
    } catch (err) {
      log.error(err);
      reject({ message: 'Failed to create topic due to unexpected error', status: 500 });
    }
  });
}

const getTopics = () => {
  return new Promise((resolve, reject) => {
    try {
      const topic = new topicModel({});
      
      log.info(`getting topics from database`);
      topic.findTopics(function(error, topics) {
        if(error) {
          log.error(error);
          reject({ message: 'Failed to fetch topics due to unexpected error', status: 500 });
        } else {
          resolve({ message: 'Successfully fetched', status: 200, topics: topics });
        }
      });
    } catch (err) {
      log.error(err);
      reject({ message: 'Failed to fetch topics due to unexpected error', status: 500 });
    }
  });
}

module.exports = {
  getTopics,
  createTopic
}
