const mongoose = require('mongoose');

let questionSchema = new mongoose.Schema({
  id: {
    type: String,
    lowercase: true,
    unique: true,
    required: true,
  },
  title: {
    type: String,
    required: true
  },
  userId: {
    type: String,
    required: true
  },
  createdOn: {
    type: String,
    default: Date.now(),
    required: true
  },
  modifiedOn: {
    type: String,
    default: Date.now(),
    required: true
  }
});

questionSchema.methods.findTopics = function (callback) {
  return this.model('topic')
    .find({})
    .exec(callback);
};

module.exports = mongoose.model('topic', questionSchema);
