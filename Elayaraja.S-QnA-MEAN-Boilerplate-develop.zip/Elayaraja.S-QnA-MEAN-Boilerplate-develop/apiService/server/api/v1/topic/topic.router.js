const router = require('express').Router();
const topicController = require('./topic.controller');

router.get('/', topicController.getTopics);
router.post('/', topicController.createTopic);

module.exports = router;
