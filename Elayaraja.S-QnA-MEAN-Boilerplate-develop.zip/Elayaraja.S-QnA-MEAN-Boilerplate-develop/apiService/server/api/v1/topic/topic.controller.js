const topicService = require('./topic.service');

const getTopics = (req, res) => {  
  topicService.getTopics()
    .then((result) => {
      res.status(result.status).json(result.topics);
    })
    .catch((error) => {
      res.status(error.status).json(error);
    });
};

const createTopic = (req, res) => {
  const topic = req.body;
  const userId = req.query.userId || req.userData.userId;
  topicService.createTopic(userId, topic)
    .then((result) => {
      res.status(result.status).json(result.topic);
    })
    .catch((error) => {
      res.status(error.status).json(error);
    });
};

module.exports = {
  getTopics,
  createTopic 
}
