const questionDao = require('./question.dao');
const log = require('../../../logging');

const getQuestionsByTopicId = (topicId) => {
  return questionDao.getQuestionsByTopicId(topicId)
}

const getQuestionsById = (questionId) => {
  return questionDao.getQuestionsById(questionId);
}

const createQuestion = (userId, question) => {
  return questionDao.createQuestion(userId, question);
}

module.exports = {
  getQuestionsByTopicId,
  getQuestionsById,
  createQuestion
}