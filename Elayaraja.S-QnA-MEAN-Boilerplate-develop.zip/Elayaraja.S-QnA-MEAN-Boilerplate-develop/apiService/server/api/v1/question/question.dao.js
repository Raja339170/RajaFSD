let questionModel = require('./question.entity');
const uuidv4 = require('uuid/v4');

const log = require('../../../logging');

const createQuestion = (userId, question) =>{
  return new Promise((resolve, reject) => {
    try {
      let newQuestion = new questionModel({
        id: uuidv4(),
        title: question.title,
        description: question.description,
        userId: userId,
        topicId: question.topicId
      });

      log.info('saving question in database');
      newQuestion.save(function(error, addedQuestion) {
        if(error) {
          log.error(error);
          reject({ message: 'Failed to create question due to unexpected error', status: 500 });
        } else {
          resolve({ message: 'Successfully created', status: 201, question: addedQuestion });
        }
      });
    } catch (err) {
      log.error(err);
      reject({ message: 'Failed to create question due to unexpected error', status: 500 });
    }
  });
}

const getQuestionsByTopicId = (topicId) => {
  return new Promise((resolve, reject) => {
    try {
      const question = new questionModel({
        topicId: topicId
      });
      
      log.info(`getting question for a topic (${topicId}) from database`);
      question.findByTopicId(function(error, question) {
        if(error) {
          log.error(error);
          reject({ message: 'Failed to fetch question due to unexpected error', status: 500 });
        } else {
          resolve({ message: 'Successfully fetched', status: 200, question: question });
        }
      });
    } catch (err) {
      log.error(err);
      reject({ message: 'Failed to fetch question due to unexpected error', status: 500 });
    }
  });
}

const getQuestionsById = (questionId) => {
  return new Promise((resolve, reject) => {
    try {
      const question = new questionModel({
        id: questionId
      });
      
      log.info(`getting answer for a question (${questionId}) from database`);
      question.findByQuestionId(function(error, qna) {
        if(error) {
          log.error(error);
          reject({ message: 'Failed to fetch answer due to unexpected error', status: 500 });
        } else {
          resolve({ message: 'Successfully fetched', status: 200, qna: qna });
        }
      });
    } catch (err) {
      log.error(err);
      reject({ message: 'Failed to fetch answer due to unexpected error', status: 500 });
    }
  });
}

module.exports = {
  createQuestion,
  getQuestionsByTopicId,
  getQuestionsById
}
