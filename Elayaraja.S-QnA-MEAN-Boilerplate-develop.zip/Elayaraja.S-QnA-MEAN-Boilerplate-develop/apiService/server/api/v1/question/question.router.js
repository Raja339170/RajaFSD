const router = require('express').Router();
const questionController = require('./question.controller');

router.get('/detail', questionController.getQuestionDetails);
router.get('/', questionController.getQuestions);
router.post('/', questionController.createQuestion);

module.exports = router;
