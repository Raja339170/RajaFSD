const mongoose = require('mongoose');

let questionSchema = new mongoose.Schema({
  id: {
    type: String,
    lowercase: true,
    unique: true,
    required: true,
  },
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  userId: {
    type: String,
    required: true
  },
  topicId: {
    type: String,
    required: true
  },
  createdOn: {
    type: String,
    default: Date.now(),
    required: true
  },
  modifiedOn: {
    type: String,
    default: Date.now(),
    required: true
  }
});

questionSchema.methods.findByTopicId = function (callback) {
  return this.model('question')
    .find({ topicId: this.topicId })
    .exec(callback);
};

questionSchema.methods.findByQuestionId = function (callback) {
  return this.model('question')
    .aggregate([
      {
        $match: { id: this.id }
      },
      {
        $lookup: {
          'from': 'answers',
          'localField': 'id',
          'foreignField': 'questionId',
          'as': 'answers'
        }
      }
    ])
    .exec(callback);
};

module.exports = mongoose.model('question', questionSchema);
