const questionService = require('./question.service');

const getQuestionDetails = (req, res) => {
  const questionId = req.query.questionId;  
  questionService.getQuestionsById(questionId)
    .then((result) => {
      res.status(result.status).json(result.qna[0]);
    })
    .catch((error) => {
      res.status(error.status).json(error);
    });
};

const getQuestions = (req, res) => {
  const topicId = req.query.topicId;  
  questionService.getQuestionsByTopicId(topicId)
    .then((result) => {
      res.status(result.status).json(result.question);
    })
    .catch((error) => {
      res.status(error.status).json(error);
    });
};


const createQuestion = (req, res) => {
  const question = req.body;
  const userId = req.query.userId || req.userData.userId;
  questionService.createQuestion(userId, question)
    .then((result) => {
      res.status(result.status).json(result.question);
    })
    .catch((error) => {
      res.status(error.status).json(error);
    });
};

module.exports = {
  getQuestionDetails,
  getQuestions,  
  createQuestion  
}
