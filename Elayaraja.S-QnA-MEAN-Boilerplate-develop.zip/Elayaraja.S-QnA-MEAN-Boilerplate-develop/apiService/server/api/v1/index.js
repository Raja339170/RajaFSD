const router = require('express').Router();

const authService = require('../../services').authServices;

router.use('/users', require('./users'));
router.use('/topic', authService.checkAuthentication, require('./topic'));
router.use('/question', authService.checkAuthentication, require('./question'));
router.use('/question/answer', authService.checkAuthentication, require('./answer'));

module.exports = router;
