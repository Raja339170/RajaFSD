## QnA Application
This is a simple node.js application with MongoDB access, can be used to implementation for QnA operations with MongoDB

This expects the environment variable MONGO_URL, which you can set using below command 

On Linux platform
```
export MONGO_URL='mongodb://localhost:27017/testDB'
echo Testing - $MONGO_URL
```

On Windows platform
```
SET MONGO_URL='mongodb://localhost:27017/testDB'
echo Testing - %MONGO_URL%
```
### Application Details:
- User can register and login & logout
- User can view topic, questions & comments.
- User can post question & comments under a particular topic.

#### Using docker-compose
- Build and start
```docker-compose up --build ```
- Stop
```docker-compose down ```
- Connect Mongo DB
```docker exec -it qna-app-dev mongo ```

- Navigate to Applicaiton http://localhost/login

## Command used to generate this project
Project is originally generated usign Angular CLI, and was added the express part manually
