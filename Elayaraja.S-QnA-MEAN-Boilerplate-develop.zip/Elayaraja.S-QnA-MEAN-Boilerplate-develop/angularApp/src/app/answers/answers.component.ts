import { Component, OnInit, Query } from '@angular/core';
import { RouterService } from '../services/router.service';
import { ActivatedRoute } from '@angular/router';
import { QuestionService } from './../services/question.service';
import { Qna } from './../qna';

@Component({
  selector: 'app-answers',
  templateUrl: './answers.component.html',
  styleUrls: ['./answers.component.css']
})
export class AnswerComponent implements OnInit {

  qna: Qna;
  questionId: string;
  constructor(private routerService: RouterService,
              private activatedRoute: ActivatedRoute,
              private questionService: QuestionService) {
    this.clearQna();
  }

  private clearQna() {
    this.qna = new Qna();
  }

  ngOnInit() {
    this.questionId = this.activatedRoute.snapshot.paramMap.get('questionId');
    this.questionService.fetchQuestionDetailsFromServer(this.questionId);
    this.questionService.getQuestionDetails()
      .subscribe(qna => {
        this.clearQna();
        this.qna = qna;
      });
  }
}
