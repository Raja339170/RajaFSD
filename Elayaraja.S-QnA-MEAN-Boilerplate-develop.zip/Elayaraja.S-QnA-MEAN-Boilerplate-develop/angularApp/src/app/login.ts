export class Login {
    username: string;
    password: string;

    constructor(username, password) {
        this.username = username;
        this.password = password;
    }
}


export class Register {
    username: string;
    fullname: string;
    password: string;

    constructor(fullname, username, password) {
        this.fullname = fullname;
        this.username = username;
        this.password = password;
    }
}
