export class Topic {
  id: string;
  title: string;

  constructor() {
    this.id = '';
    this.title = '';
  }
}

export class Question {
  id: string;
  title: string;
  description: string;
  topicId: string;

  constructor() {
    this.title = '';
    this.description = '';
    this.topicId = '';
  }
}

export class Answer {
  id: string;
  text: string;
  questionId: string;

  constructor() {
    this.text = '';
    this.questionId = '';
  }
}

export class Qna {
  id: string;
  title: string;
  description: string;
  topicId: string;
  answers: Array<Answer>;

  constructor() {
    this.title = '';
    this.description = '';
    this.topicId = '';
    this.answers = [];
  }
}
