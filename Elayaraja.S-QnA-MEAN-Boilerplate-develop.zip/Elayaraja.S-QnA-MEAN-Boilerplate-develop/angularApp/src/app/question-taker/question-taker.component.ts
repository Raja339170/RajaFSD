import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { Question } from '../qna';
import { HttpErrorResponse } from '@angular/common/http';
import { QuestionService } from '../services/question.service';

@Component({
  selector: 'app-question-taker',
  templateUrl: './question-taker.component.html',
  styleUrls: ['./question-taker.component.css']
})
export class QuestionTakerComponent implements OnInit {
  errMessage: string;
  question: Question;
  @Input() topicId: string;

  constructor(private questionsService: QuestionService) { }

  ngOnInit() {
    this.question = new Question();
    this.question.topicId = this.topicId;
  }

  addQuestion() {
    this.errMessage = '';
    if (this.validateQuestion(this.question)) {
      this.questionsService.addQuestion(this.question).subscribe(
        data => this.question = new Question(),
        error => this.handleErrorResponse(error)
      );
    }
  }

  validateQuestion(question): boolean {
    if (question.title === '' ||
        !question.title.trim() ||
        question.description === '' ||
        !question.description.trim()) {
      this.errMessage = 'Title and Description both are required fields';
      return false;
    }
    return true;
  }

  handleErrorResponse(error: HttpErrorResponse): void {
    if (error.status === 404) {
      this.errMessage = error.message;
    } else {
      this.errMessage = 'An error occurred:' + error.error.message;
    }
  }
}
