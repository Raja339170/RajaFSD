import { Component, OnInit } from '@angular/core';
import { RouterService } from '../services/router.service';
import { ActivatedRoute } from '@angular/router';
import { Question } from '../qna';
import { QuestionService } from '../services/question.service';

@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.css']
})
export class QuestionComponent implements OnInit {

  questions: Array<Question>;
  topicId: string;
  constructor(private routerService: RouterService,
              private activatedRoute: ActivatedRoute,
              private questionService: QuestionService) {
    this.clearQuestions();
  }

  private clearQuestions() {
    this.questions = new Array<Question>();
  }

  ngOnInit() {
    this.topicId = this.activatedRoute.snapshot.paramMap.get('topicId');
    this.questionService.fetchTopicQuestionsFromServer(this.topicId);
    this.questionService.getTopicQuestions()
      .subscribe(questions => {
        this.clearQuestions();
        this.questions = questions;
      });
  }

  openAnswerView(questionId) {
    this.routerService.routeToAnswerView(questionId);
  }
}
