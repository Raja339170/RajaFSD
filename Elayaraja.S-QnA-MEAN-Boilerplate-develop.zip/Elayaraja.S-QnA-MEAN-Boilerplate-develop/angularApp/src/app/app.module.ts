import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';

// material imports
import {
  MatToolbarModule,
  MatExpansionModule,
  MatFormFieldModule,
  MatInputModule,
  MatButtonModule,
  MatCardModule,
  MatIconModule,
  MatOptionModule,
  MatSelectModule,
  MatDialogModule,
  MatSidenavModule,
  MatTooltipModule,
  MatSnackBarModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatListModule,
  MatMenuModule,
  MatAutocompleteModule
} from '@angular/material';

// components inports
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HeaderComponent } from './header/header.component';
import { TopicComponent } from './topic/topic.component';
import { TopicTakerComponent } from './topic-taker/topic-taker.component';
import { QuestionComponent } from './question/question.component';
import { AnswerComponent } from './answers/answers.component';
import { QuestionTakerComponent } from './question-taker/question-taker.component';
import { AnswerTakerComponent } from './answer-taker/answer-taker.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { LogoutComponent } from './logout/logout.component';

// services imports
import { AuthenticationService } from './services/authentication.service';
import { RouterService } from './services/router.service';
import { TopicService } from './services/topic.service';
import { QuestionService } from './services/question.service';

// guards imports
import { CanActivateRouteGuard } from './can-activate-route.guard';

// custom routes
const appRoutes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'register',
    component: RegisterComponent
  },
  {
    path: 'logout',
    component: LogoutComponent
  },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [ CanActivateRouteGuard ],
    children: [
      {
        path: 'view/topic',
        component: TopicComponent
      }
    ]
  },
  {
    path: 'topic/:topicId',
    component: QuestionComponent
  },
  {
    path: 'question/:questionId',
    component: AnswerComponent
  },
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  }
];

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    HeaderComponent,
    TopicComponent,
    TopicTakerComponent,
    QuestionComponent,
    AnswerComponent,
    QuestionTakerComponent,
    AnswerTakerComponent,
    LoginComponent,
    RegisterComponent,
    LogoutComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    RouterModule,
    MatToolbarModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    MatOptionModule,
    MatSelectModule,
    MatDialogModule,
    MatSidenavModule,
    MatTooltipModule,
    MatSnackBarModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatListModule,
    MatMenuModule,
    MatAutocompleteModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [
    QuestionService,
    TopicService,
    RouterService,
    AuthenticationService,
    CanActivateRouteGuard
  ],
  bootstrap: [ AppComponent ],
  entryComponents: [
    TopicComponent
  ]
})

export class AppModule { }
