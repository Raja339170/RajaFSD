import { TopicService } from './../services/topic.service';
import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { Topic } from '../qna';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-topic-taker',
  templateUrl: './topic-taker.component.html',
  styleUrls: ['./topic-taker.component.css']
})
export class TopicTakerComponent implements OnInit {
  errMessage: string;
  topic: Topic;

  constructor(private topicService: TopicService) { }

  ngOnInit() {
    this.topic = new Topic();
  }

  addTopic() {
    this.errMessage = '';
    if (this.validateTopic(this.topic)) {
      this.topicService.addTopic(this.topic).subscribe(
        data => this.topic = new Topic(),
        error => this.handleErrorResponse(error)
      );
    }
  }

  validateTopic(topic): boolean {
    if (topic.title === '' ||
        !topic.title.trim()) {
      this.errMessage = 'Topic title is required field';
      return false;
    }
    return true;
  }

  handleErrorResponse(error: HttpErrorResponse): void {
    if (error.status === 404) {
      this.errMessage = error.message;
    } else {
      this.errMessage = 'An error occurred:' + error.error.message;
    }
  }
}
