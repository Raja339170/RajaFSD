import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Topic } from './../qna';
import { AuthenticationService } from './authentication.service';
import { BehaviorSubject} from 'rxjs/BehaviorSubject';
import { Observable} from 'rxjs/Observable';
import { tap } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable()
export class TopicService {
  baseUrl = environment.appServicesUrl + 'api/v1/topic';
  topics: Array<Topic>;
  topicsSubject: BehaviorSubject<Array<Topic>>;

  constructor(private httpClient: HttpClient,
              private authenticationService: AuthenticationService) {
                this.topics = [];
                this.topicsSubject = new BehaviorSubject(this.topics);
              }

  fetchTopicsFromServer(): void {
    const headers = this.getAuthorizationHeader();
    this.httpClient.get<Array<Topic>>(`${this.baseUrl}`, { headers })
      .subscribe(data => {
          this.topics = data;
          this.topicsSubject.next(this.topics);
        },
        errro => { }
      );
  }

  getTopics(): BehaviorSubject<Array<Topic>> {
    return this.topicsSubject;
  }

  addTopic(topic: Topic): Observable<Topic> {
    const headers = this.getAuthorizationHeader();
    return this.httpClient.post<Topic>(`${this.baseUrl}`, topic, { headers })
      .pipe(tap(
        data => {
          this.topics.push(data);
          this.topicsSubject.next(this.topics);
        },
        error => { }
      ));
  }

  private getAuthorizationHeader() {
    const token = this.authenticationService.getBearerToken();
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return headers;
  }
}
