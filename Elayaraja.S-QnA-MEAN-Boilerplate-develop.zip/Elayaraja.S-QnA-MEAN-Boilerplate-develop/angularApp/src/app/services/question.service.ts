import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Question, Answer, Topic, Qna } from './../qna';
import { AuthenticationService } from './authentication.service';
import { BehaviorSubject} from 'rxjs/BehaviorSubject';
import { Observable} from 'rxjs/Observable';
import { tap } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable()
export class QuestionService {
  baseUrl = environment.appServicesUrl + 'api/v1/question';
  questions: Array<Question>;
  questionSubject: BehaviorSubject<Array<Question>>;
  questionDetails: Qna;
  questionDetailsSubject: BehaviorSubject<Qna>;
  topics: Array<Topic>;
  topicsSubject: BehaviorSubject<Array<Topic>>;

  constructor(private httpClient: HttpClient,
              private authenticationService: AuthenticationService) {
                this.questions = [];
                this.questionSubject = new BehaviorSubject(this.questions);
                this.questionDetails = new Qna();
                this.questionDetailsSubject = new BehaviorSubject(this.questionDetails);
                this.topics = [];
                this.topicsSubject = new BehaviorSubject(this.topics);
              }

  fetchTopicsFromServer(): void {
    const headers = this.getAuthorizationHeader();
    this.httpClient.get<Array<Topic>>(`${this.baseUrl}/topic`, { headers })
      .subscribe(data => {
          this.topics = data;
          this.topicsSubject.next(this.topics);
        },
        errro => { }
      );
  }

  getTopics(): BehaviorSubject<Array<Topic>> {
    return this.topicsSubject;
  }

  fetchTopicQuestionsFromServer(topicId): void {
    const headers = this.getAuthorizationHeader();
    this.httpClient.get<Array<Question>>(`${this.baseUrl}?topicId=${topicId}`, { headers })
      .subscribe(data => {
          this.questions = data;
          this.questionSubject.next(this.questions);
        },
        errro => { }
      );
  }

  getTopicQuestions(): BehaviorSubject<Array<Question>> {
    return this.questionSubject;
  }

  fetchQuestionDetailsFromServer(questionId): void {
    const headers = this.getAuthorizationHeader();
    this.httpClient.get<Qna>(`${this.baseUrl}/detail?questionId=${questionId}`, { headers })
      .subscribe(data => {
          this.questionDetails = data;
          this.questionDetailsSubject.next(this.questionDetails);
        },
        errro => { }
      );
  }

  getQuestionDetails(): BehaviorSubject<Qna> {
    return this.questionDetailsSubject;
  }

  addQuestion(question: Question): Observable<Question> {
    const headers = this.getAuthorizationHeader();
    return this.httpClient.post<Question>(`${this.baseUrl}`, question, { headers })
      .pipe(tap(
        data => {
          this.questions.push(data);
          this.questionSubject.next(this.questions);
        },
        error => { }
      ));
  }

  getQuestionById(questionId: string): Question {
    const foundQuestion = this.questions.find(n => n.id === questionId);
    return Object.assign({}, foundQuestion);
  }

  addAnswer(answer: Answer): Observable<Answer> {
    const headers = this.getAuthorizationHeader();
    return this.httpClient.post<Answer>(`${this.baseUrl}/answer`, answer, { headers })
      .pipe(tap(
        data => {
          this.questionDetails.answers.push(data);
          this.questionDetailsSubject.next(this.questionDetails);
        },
        error => { }
      ));
  }

  addTopic(topic: Topic): Observable<Topic> {
    const headers = this.getAuthorizationHeader();
    return this.httpClient.post<Topic>(`${this.baseUrl}/topic`, topic, { headers })
      .pipe(tap(
        data => {
          this.topics.push(data);
          this.topicsSubject.next(this.topics);
        },
        error => { }
      ));
  }

  private getAuthorizationHeader() {
    const token = this.authenticationService.getBearerToken();
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return headers;
  }
}
