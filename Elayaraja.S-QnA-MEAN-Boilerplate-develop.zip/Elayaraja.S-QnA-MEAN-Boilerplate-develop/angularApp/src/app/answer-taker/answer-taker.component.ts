import { QuestionService } from './../services/question.service';
import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { Answer } from '../qna';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-answer-taker',
  templateUrl: './answer-taker.component.html',
  styleUrls: ['./answer-taker.component.css']
})
export class AnswerTakerComponent implements OnInit {
  errMessage: string;
  answer: Answer;
  @Input() questionId: string;

  constructor(private questionService: QuestionService) { }

  ngOnInit() {
    this.answer = new Answer();
  }

  addAnswer() {
    this.errMessage = '';
    if (this.validateAnswer(this.answer)) {
      this.answer.questionId = this.questionId;
      this.questionService.addAnswer(this.answer).subscribe(
        data => this.answer = new Answer(),
        error => this.handleErrorResponse(error)
      );
    }
  }

  validateAnswer(answer): boolean {
    if (answer.text === '' ||
        !answer.text.trim()) {
      this.errMessage = 'Answer text is required field';
      return false;
    }
    return true;
  }

  handleErrorResponse(error: HttpErrorResponse): void {
    if (error.status === 404) {
      this.errMessage = error.message;
    } else {
      this.errMessage = 'An error occurred:' + error.error.message;
    }
  }
}
