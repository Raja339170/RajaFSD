import { TopicService } from './../services/topic.service';
import { Component, OnInit } from '@angular/core';
import { RouterService } from '../services/router.service';
import { Topic } from '../qna';
import { QuestionService } from '../services/question.service';

@Component({
  selector: 'app-topic',
  templateUrl: './topic.component.html',
  styleUrls: ['./topic.component.css']
})
export class TopicComponent implements OnInit {

  topicsSubject: Array<Topic>;

  constructor(private routerService: RouterService, private topicService: TopicService) {
    this.clearTopics();
  }

  private clearTopics() {
    this.topicsSubject = new Array<Topic>();
  }

  ngOnInit() {
    this.topicService.getTopics()
      .subscribe(topics => {
        this.clearTopics();
        this.topicsSubject = topics;
      });
  }

  openQuestionView(topicId) {
    this.routerService.routeToQuesionView(topicId);
  }
}
