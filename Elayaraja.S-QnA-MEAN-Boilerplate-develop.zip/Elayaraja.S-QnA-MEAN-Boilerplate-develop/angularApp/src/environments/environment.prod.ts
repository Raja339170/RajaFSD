export const environment = {
  production: true,
  appServicesUrl: 'http://localhost:3000/'
};
