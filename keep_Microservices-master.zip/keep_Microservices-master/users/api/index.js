const router = require('express').Router();

router.use('/users', require('./v1/users'));

router.use((req, res) => {
    res.status(404).send('Not Found.');
});

module.exports = router;