const router = require('express').Router();
const users = require('../.././db.json');

router.all('*', function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});

router.get('/', (req, res) => {
    if (users) {
        res.status(200).send(users);
    }
    res.status(200).send();
});

router.get('/:userId', (req, res) => {
    const user = users.find((user) => {
        return user.userId == req.params.userId;
    });

    if (user) {
        res.status(200).send(user);
    }
    res.status(200).send();
});

router.get((req, res) => {
    res.status(200).send('Not found.');
});

module.exports = router;