const request = require('supertest');
const assert = require('chai').assert;
const app = require('../notes/app.js');


describe('Test Suit for notes', () => {
    it('Should send notes as a response', (done) => {
        request(app)
            .get('/api/notes')
            .expect(200)
            .end((err, res) => {
                if (err) return done(err);
                assert.isNotEmpty(res.body);
                done();
            });
    });
    it('Should send notes for userid as a response', (done) => {
        request(app)
            .get('/api/notes/3')
            .expect(200)
            .end((err, res) => {
                if (err) return done(err);
                assert.isNotEmpty(res.body);
                done();
            });
    });
});