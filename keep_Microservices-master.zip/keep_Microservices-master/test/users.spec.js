const request = require('supertest');
const assert = require('chai').assert;
const app = require('../users/app.js');

describe('Test Suit for users', () => {
    it('Should send user details for userid', (done) => {
        request(app)
            .get('/api/users/3')
            .expect(200)
            .end((err, res) => {
                if (err) return done(err);
                assert.isNotEmpty(res.body);
                done();
            });
    });
    

    it('Should send user details for test', (done) => {
        request(app)
            .get('/api/users')
            .expect(200)
            .end((err, res) => {
                if (err) return done(err);
                assert.isNotEmpty(res.body);
                done();
            });
    });
});