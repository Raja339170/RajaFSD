const express = require('express');
const api = require('./api');

let app = express();

app.use('/api', api);

app.use((req, res) => {
    res.status(200).send('No Resource found!');
});

module.exports = app;