const router = require('express').Router();

router.use('/notes',require('./v1/notes'));

router.use((req, res) => {
    res.status(404).send('Not Found.');
});

module.exports = router;