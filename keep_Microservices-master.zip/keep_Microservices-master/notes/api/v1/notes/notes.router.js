const router = require('express').Router();
const notes = require('../.././db.json');

router.all('*', function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});

router.get('/', (re1, res) => {
    res.status(200).send(notes);
});

router.get('/:userId', (req, res) => {
    const note = notes.find((note) => {
        return note.userId == req.params.userId;
    });
    if (note) {
        res.status(200).send(note);
    }
    res.status(200).send();
});

router.get((req, res) => {
    res.status(200).send('Not found.');
});

module.exports = router;