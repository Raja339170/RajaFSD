let config = {
    WWW_PORT: (process.env.port || 8000),
    notes_URL: (process.env.notes_URL || 'http://localhost:8010'),
    users_URL: (process.env.users_url || 'http://localhost:8020')
}

module.exports = config;